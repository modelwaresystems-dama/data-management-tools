---
name: "rfp-cv-tailor"
description: "Tailor Howard Diesel's CV to a specific RFP/tender (scope-trimmed CV + honest coverage map; PDF default, .pptx/.docx on request), draft the tender's Expert Services Agreement (ESA .docx + Annex A from the Modelware Standard Clauses), and — when a team is proposed — run a multi-person triage that scores each person's fit and recommends bid / partner / leave. When his Tender Console repo is connected, the run files itself into it, and the skill can also act as the request-queue worker that fulfils queued assessment requests from data/requests.json. Use whenever Howard or a salesperson supplies a tender/RFP/proposal and wants a CV, an ESA, or a bid/partner/leave assessment targeted to it."
---

# RFP CV Tailor

Turns a target tender plus Howard's existing CV(s) into a CV that answers what *that* tender is actually asking for, alongside an honest coverage map. Every interactive run stops twice for Howard's approval — once on how to run it, once on the tailoring plan — before anything is generated. When the Tender Console repo is connected, the same run files itself into that repo, can draft the tender's Expert Services Agreement, and — when a team has been proposed — can assess the whole team's fit. Howard-specific for CV content; team-aware for triage.

The whole point is a CV that reads as if it were written for this bid, built **only** from things the person has really done. The friction below (two approval gates, the anti-fabrication rules) exists because these bids are reinsurance / DAMA-REP contexts where an inflated claim is worse than a missing one — a gap Howard knows about he can address in the proposal narrative; a fabrication he doesn't know about can sink the bid. (The one place the two approval gates do **not** run is **Worker mode**, which is headless by design — see that section.)

## Inputs (ask for whatever is missing — don't proceed on assumptions)

1. **The tender / RFP / proposal brief** (PDF, Word, or pasted text) — the thing being bid on. When the repo is connected, uploaded RFPs live under `rfp/<tenderId>/`.
2. **One or more CVs.** For Howard, prefer his designed CV **deck (.pptx)** — it is the branding source (headshot + colours) and the base for the `.pptx` replica. The most recent dated file is the base; older CVs are mined only for lines the base dropped. Read *all* supplied CVs before deciding what is missing. When the Tender Console repo is connected, each person's base CV(s) live under **`cvs/base/<personId>/`** (Howard included — no loose files at `cvs/base/` root as of contract v1.4.1).
3. **For a team triage:** the tender's **proposed team** (`teamProposed[]` on the record) and the people's entries in `data/team.json`, each with their `cvRefs`. People may be Modelware staff or **external / JV** partners (`external:true`).
4. **Optional focus items for this bid** — experience to foreground. Howard's confirmed standing set lives in `references/experience-bank.md` (and, when connected, `data/experience.json`); treat it as a starting point to confirm and extend per bid, not as licence to assert anything unconfirmed.
5. **For an ESA:** the client/consultant **base Expert Services Agreement** if one exists (the prime's paper), plus the level of effort, daily rate and milestone deliverables from the RFP/TOR.

If the tender is present but no CV is, ask for the deck rather than reconstructing a CV from memory.

## Anti-fabrication rules (non-negotiable)

These override every other instruction, including any tender scoring language that rewards a credential someone lacks.

- **Never invent or alter verifiable facts:** employers, job titles, dates, durations, certifications, client names, headcounts, metrics, or outcomes — for Howard or for any team member.
- **"Full rewrite" and "closest match" re-voice REAL experience** into the tender's language and priorities. They restructure and rephrase what the person did; they never assert something they did not do.
- **Gap-fill and supplementary content comes ONLY** from the person's confirmed experience (Howard's bank, or a team member's own CV) or what is confirmed this run — each item shown for approval *before* it appears in any output.
- **The coverage map tells the truth.** A requirement nobody can evidence is marked as a gap, not papered over. Honest gaps are a feature: they feed the wider proposal and the partner search.
- **Never assert credentials Howard doesn't hold** even when the tender prizes them — e.g. Arabic fluency, reinsurance-specific delivery, KSA residency/citizenship. Surface them as gaps. (Confirmed standing facts: in KSA since 2021, strong KSA business-culture understanding, Arabic **not** spoken, **no** reinsurance-specific engagement.)
- **An external person's credentials come only from their supplied CV** — never inferred from their firm or role.
- **When the CVs or the bank conflict with a proposed pick, raise it as a question** — do not resolve it silently and report afterwards. (In Worker mode, where no human is present, record the conflict in the assessment rather than pausing.)
- **ESA clause bodies are not free text to invent.** They come from `esa-standard-clauses.json`; only placeholders are filled per tender. The ESA carries a drafting caveat: it is commercial wording, not legal advice, to be checked by counsel before signature.

## Tender Console integration — the data contract (v1.6.0)

When Howard's **Tender Console data repo** is reachable as a connected local folder (default `tender-console-data`, containing `data/tenders.json`, `data/team.json`, `data/experience.json`, `data/harvest.json`, `data/sfia-profile.json`, `data/esa-standard-clauses.json`, `data/requests.json` (the assessment request queue), and `cvs/`, `rfp/`, `esa/` areas), this skill reads its inputs from the repo and writes its outputs back into it, so the app shows the result. Authoritative schema: read **`DATA-CONTRACT.md`** (in the app repo) — currently **v1.6.0**. If no such folder is connected, run in **standalone mode** — deliver files to chat and say the run was not filed.

- **Access = device bridge (interactive runs).** Read/write the connected local folder directly with the device tools (`device_bash`/`device_list_dir` to read, `device_commit_files` to write). **No GitHub token passes through the skill.** After writing, **committing & pushing is Howard's step** — say so; never assume it is pushed. The app reads the GitHub *remote*, so nothing appears in the app until he pushes. (**Worker mode is the exception**: it runs on a GitHub runner that has the repo checked out, and the GitHub Actions workflow — not this skill — commits the edits. See that section.)
- **The skill creates/updates the tender record** in `data/tenders.json`: id, client, title, sector, source, deadline; `status:"reviewing"`; **`goNoGo:{decision:"undecided", reason:""}`** — the bid call stays Howard's, in the app. The decision enum is **`undecided|bid|partner|leave|at-risk`** and the single free-text field is **`reason`** (never `note`). Last-writer-wins: read the whole file, change the one record, write it back. Do not set `createdBy`/`loadedBy` — the app stamps those from the signed-in person.
- **Base-CV paths:** each person's base CV is under `cvs/base/<personId>/`; the lead's is `cv.baseRef`. Tailored CVs + coverage go under `cvs/tailored/<id>/`.
- **`team.json` is READ-ONLY to this skill** — the app's Team tab owns it. It is the registry of people who can be proposed (Modelware staff and, with `external:true`, JV/partner associates), each with `cvRefs`. Use it to resolve `teamProposed[]` ids to people and their CVs. **Never edit `team.json`** (and never `sfia-profile.json` — the app owns it too).
- **`teamProposed[]`** (person-ids) is how a tender's people are recorded; it **replaces the old `cv.teamRefs[]`** (retired at v1.4.1). A record's people come from `teamProposed[]`, their CVs from each person's `team.json` `cvRefs`.
- **Fill `requirements[]`** each `{text, weight, rating, evidence}` plus, per the contract, optional `sfia[]` `{code, requiredLevel}` and `responsibility[]` `{attr, requiredLevel}` proposed from the wording for confirmation. **Weights — never leave blank:** if the RFP states weights, use them; if not, recommend weights from the tender's emphasis (summing to 100%) in the Phase 1 register for Howard to adjust, labelled as recommendations, not RFP-stated figures.
- Write the tailored CV + coverage map into `cvs/tailored/<id>/`; set `cv.baseRef/tailoredRef/coverageRef`; draft `compliance[]` (mandatory/disqualifying clauses only — never conflated with a scoring gap); set `updatedAt`; append reusable bullets to `data/harvest.json`.

## Triage mode — assess a proposed team (decision SI3)

When a tender has a **proposed team** (`teamProposed[]` set — e.g. a salesperson loaded the tender and named who should deliver it) and Howard or the salesperson asks to **review / assess** it:

1. **Read** the tender record, the uploaded RFP under `rfp/<id>/`, `data/team.json`, and **each proposed person's** `cvRefs` (CVs under `cvs/base/<personId>/`), plus `experience.json` and `sfia-profile.json`.
2. **Extract the requirements** (as in CV mode) and map **each proposed person's** CV to them → a per-person fit: which requirement codes they cover, their gaps.
3. **Compute the team's collective coverage,** name the **gaps a partner would fill** (`partnerNeeds[]`), and flag any hard **disqualifiers** (mandatory clauses the team/firm can't meet).
4. **Write `assessment{}`** into the record: `recommendation` (`bid|partner|leave|at-risk|undecided`), `rationale`, `overallFit`, `people[]` (one per proposed member: `personId, fit, verdict, covers[], gaps[], note`), `partnerNeeds[]`, `disqualifiers[]`, **`status`**, `confirmedBy`/`confirmedAt`, `assessedBy, assessedAt`. Set **`status:"proposed"`** by default (a human confirms it in the app); a direct run that Howard reviews with you in the room may set **`status:"confirmed"`** with `confirmedBy`/`confirmedAt`. **The recommendation is a proposal only** — leave `goNoGo.decision` for Howard (decision SI4: salespeople propose, Howard decides). **Integrity:** every `people[].personId` must be in `teamProposed[]`, and every id in `teamProposed[]` must exist in `team.json`.
5. **Tell the user** what was written and that someone still needs to **commit & push** (interactive runs).

Triage is the multi-person, pre-decision step; CV/coverage and ESA modes are unchanged. A person's fit comes only from their real CV — see the anti-fabrication rules.

## Worker mode — fulfil queued assessment requests (v1.6.0, GitHub Actions)

The Tender Console app is a static page with no backend, so staff cannot run this skill from it. Instead the app **enqueues** a request in `data/requests.json`, and this skill runs as a **GitHub Actions worker** — a workflow (`.github/workflows/assessment-worker.yml`) in the private data repo that runs `anthropics/claude-code-action` and invokes this skill in Worker mode on a runner. Full design + runbook: `REQUEST-QUEUE-HANDOVER.md` and `WORKER-SETUP.md` (app repo). One run at a time (a concurrency group); **stateless** between runs (the queue file is the entire shared state). Triggered on push to `requests.json`.

**Headless discipline.** There is no human in this session. Do **not** run the Phase 0 / Phase 1 approval gates and do **not** ask questions — the human review gate is the app's **Confirm** step, which happens later. If an input is missing, record it as a gap or fail the request with a clear error; never pause for approval.

Each run:

1. **Read `data/requests.json`** (the repo is checked out; locate it with Glob). Select the **oldest `status:"queued"`** request — plus any `running` row whose `claimedAt` is older than the stale timeout (~20 min; a crashed run left it dangling). If nothing is actionable, make **no** file changes and stop.
2. **Gather inputs** for the request's `tenderId`: the tender record, `team.json`, each `teamProposed[]` person's `cvRefs` (CVs under `cvs/base/<id>/`), the RFP under `rfp/<tenderId>/`, plus `experience.json` and `sfia-profile.json`.
3. **Run triage mode** (above) → per-person fit, team coverage, `partnerNeeds[]`, `disqualifiers[]`, and a `bid`/`partner`/`leave`/`at-risk` recommendation. Obey the anti-fabrication rules — a person's fit comes only from their real CV.
4. **Write results:** merge `assessment{}` onto the one tender record in `tenders.json` (read the whole file, change only that record, write it back). Set **`status:"proposed"`**, `confirmedBy:null`, `confirmedAt:null`, `assessedBy:"worker:gha"`, `assessedAt`. Integrity: every `assessment.people[].personId` ∈ `teamProposed[]` ∈ `team.json`.
5. **Close the request** in `requests.json`: `status:"done"`, `completedAt`, `claimedBy:"worker:gha"`, `result` (one-line summary, e.g. `"partner · team fit 71% (2 people) · proposed"`). Trim `done` rows older than ~30 days.
6. **Do not run git.** The GitHub Actions workflow commits your file edits with the built-in `GITHUB_TOKEN` and pushes. You only **edit the files** and stop.
7. **On any failure:** set the request `status:"error"`, `error` (the message), `attempts++`, leave `tenders.json` untouched, and stop — never leave a row stuck in `running`.

**Boundaries (non-negotiable):** the worker writes **only** `assessment{}` (onto the tender, always `status:"proposed"`) and request status. It **never** sets `goNoGo.decision` (an admin's call), never confirms its own assessment, never edits `team.json` or `sfia-profile.json`, and never writes to the public app repo. Model auth is the `CLAUDE_CODE_OAUTH_TOKEN` Actions secret; git write is the per-run `GITHUB_TOKEN` — **there is no worker PAT**. `assessment{}` is a proposal — a bad run is disregardable and re-runnable by an admin, and is never mistaken for a confirmed assessment or the bid call.

## ESA mode — draft the tender's Expert Services Agreement (decision E5 = this skill)

When Howard asks for the ESA (or a tender needs one), after the CV/coverage flow:

1. **Read** the tender record, `data/esa-standard-clauses.json` (Modelware's versioned protective overlay — 12 clauses incl. scope boundaries, acceptance-on-own-scope, payment protection + longstop, change control, Background IP, Separation & pro-rata), and the client/consultant **base ESA** if supplied (under `esa/<id>/`). Whose paper is the base is per decision **E2** (default: client/consultant base + Modelware overlay; `modelware` master allowed).
2. **Extract/confirm the ESA specifics** from the RFP/TOR + tender: parties (Expert = Modelware Systems (Pty) Limited, Expert Rep = Howard Diesel; Consultant; Client), role + short role tag, reference, level of effort (days), daily rate, max fee, and the **milestone deliverables** — each output linked to a `requirements[]` code (`reqRef`) where it maps to scope (decision **E4**).
3. **Present the ESA plan for approval** (same two-gate discipline): the milestone/deliverable breakdown with day/fee split, and which standard clauses to include/exclude (recommend the full set; flag any the tender makes irrelevant). Do not generate until approved.
4. **On approval, assemble** the tailored **ESA `.docx`** (base terms + Standard Clauses with `{{PLACEHOLDERS}}` filled from the tender) and **Annex A** (deliverables, responsibilities, day/fee budget) into `esa/<id>/`; optionally a **redline** against the base. ESA prose = the clause bodies from the clause-set file with placeholders filled; do not invent clause text.
5. **Write the `esa{}` block** into the tender record (status `proposed`): parties, commercial, `baseAgreement`, `clauseSet{ref,version,included,excluded}`, `milestones[]`→`outputs[]` with `reqRef`, `docs{esaRef,annexRef,redlineRef}`, `updatedAt`. Record the `clauseSet.version` the ESA was built against.
6. **Tell Howard** which files/records changed and that he still needs to **commit & push**.

## Workflow — three phases, two stops

### Phase 0 — Config register (stop and confirm)

Run this **every tender** in an interactive run (Worker mode skips it). Read `references/config-register.md`, present its questions as a decision-register-style artifact (or `AskUserQuestion`) with recommended defaults pre-marked, and get Howard's answers. Do not start Phase 1 until confirmed. Key outputs: which formats (PDF always; `.pptx`/`.docx` on request), tailoring depth, length target, bid-specific focus items, **whether to produce the ESA this run**, and **whether this is a single-CV run or a team triage**. When the repo is connected, the destination defaults to the repo; let Howard opt out to chat-only.

### Phase 1 — Plan register (stop and confirm)

1. **Extract the tender's requirements:** scope workstreams, team/credential criteria, mandatory qualifications, explicit scoring language. Separate evaluation requirements (scored) from mandatory/disqualifying clauses (eligibility).
2. **Read all supplied CVs + the experience bank** (`data/experience.json` when integrated; for triage, each proposed person's CV). Build the requirement → evidence map: for each requirement the CV line(s) that answer it, marked **strong / partial / gap**. For a triage, build it per person and as a team total.
3. **For each gap,** draft a proposed closest-match line from real experience, or mark it genuinely unmet and needing input (for a triage, flag it as a partner need).
4. **Draft the plan:** headline/profile re-angle, credentials to promote, what to cut, gap-fill drafts — each approvable. When a triage is in scope, include the per-person fit summary and the draft bid/partner/leave recommendation. When ESA is in scope, include the milestone/deliverable + clause-selection plan.
5. **Present Phase 1 as a decision-register-style artifact.** Get approval. **Do not generate or file anything until Howard approves.**

(Phase 0 and Phase 1 are the two human gates. **Worker mode runs neither** — it is headless, and the human gate is the app's Confirm step.)

### Phase 2 — Generate and file (after approval only)

Read `references/build-recipe.md` for exact per-format build steps, brand values, and headshot extraction before building.

1. **Always: the PDF** — lightly-branded (Modelware colours + headshot), clean single-flow A4 layout, scope-trimmed.
2. **On request: `.pptx`** — the full designed 3-page replica of Howard's CV deck, retailored.
3. **On request: `.docx`** — a clean, Modelware-branded, hand-editable Word CV.
4. **Always: the coverage map** as a companion (requirement → evidence → residual gap).
5. **For a triage: the `assessment{}`** written into the record (per Triage mode above).
6. **On request: the ESA** — ESA `.docx` + Annex A (+ optional redline) per ESA mode above.
7. **Write the CV body as a full rewrite** in the tender's language, most scope-relevant credentials leading. Fold in only approved gap-fills.
8. **When integrated: file into the repo** — update `data/tenders.json` (requirements, cv refs, compliance, `assessment{}`, `esa{}` block), write docs under `cvs/tailored/<id>/` and `esa/<id>/`, append to `data/harvest.json`. Then tell Howard exactly what changed and that **he still needs to commit & push**.
9. **Deliver every produced file** and note residual gaps for the wider proposal narrative.

## Reference files

- `references/config-register.md` — the Phase 0 config register + recommended defaults. Read at Phase 0.
- `references/experience-bank.md` — Howard's confirmed, foregroundable experience and known gaps. Read at Phase 1. Live source of truth is his memory (`cv-experience-bank`) and, when connected, `data/experience.json`; if they disagree, trust the repo/memory and confirm with Howard.
- `references/build-recipe.md` — exact build steps for PDF / PPTX / DOCX, brand palette, headshot extraction, delivery. Read at Phase 2.
- `DATA-CONTRACT.md` (in the Tender Console app repo, v1.6.0) — authoritative schema for `tenders.json` (incl. `goNoGo`, `teamProposed[]`, `assessment{}` with its `status`/`confirmedBy`/`confirmedAt` lifecycle, `esa{}`), `team.json`, `requests.json`, `sfia-profile.json` and `esa-standard-clauses.json`. Read when filing into the repo, running a triage, fulfilling a queued request, or building an ESA.
- `REQUEST-QUEUE-HANDOVER.md` and `WORKER-SETUP.md` (in the app repo) — full design + runbook for the assessment request queue and the GitHub Actions worker. Read when running as the worker.

## Notes

- First validated test case: Riyadh Re IT Strategy RFP (ref Strategy 2026-08) — PDF + coverage map delivered.
- ESA support added 2026-09-26 (decision E5 = extend this skill). Modelware ESA Standard Clauses v1.0.0 = 12 clauses distilled from the Zambia K-2 v2 overlay + the Separation clause; base ESA is usually the prime's paper with Modelware's clauses as the overlay (E2).
- **v1.4.1 (2026-10-20):** synced to data contract v1.4.1 for the salespeople extension — `cvs/base/<personId>/` layout; `goNoGo` uses `reason` with `at-risk`/`partner`/`leave` added; `team.json` registry (read-only here) with an `external` flag for JV/partner people; `teamProposed[]` replaces the retired `cv.teamRefs[]`; and **triage mode** (decision SI3) for multi-person bid/partner/leave assessment. Word/PPTX stay: PDF primary, `.pptx`/`.docx` on request.
- **v1.5.0 (2026-10-20):** added **worker mode** — fulfils queued assessment requests from `data/requests.json` (decisions RX0/RX1/RX2) by running triage; originally designed to auto-push with the worker's own scoped bot PAT. **Superseded by v1.6.0.**
- **v1.6.0 (2026-10-20):** worker mode moved to **GitHub Actions** (register `EJwjtgC8WToykzEqK1vm3n`): a workflow in the data repo runs this skill via `anthropics/claude-code-action`, triggered on push to `requests.json`, authenticating with a **Claude subscription OAuth token** (`CLAUDE_CODE_OAUTH_TOKEN`) and committing with the built-in **`GITHUB_TOKEN`** — **no worker PAT** (supersedes v1.5.0 RX2=a). **Draft-then-confirm:** the worker writes `assessment.status:"proposed"`; an admin **Confirms** in the app (`"confirmed"` + `confirmedBy`/`confirmedAt`). New `assessment` fields `status`/`confirmedBy`/`confirmedAt` (contract v1.6.0). Worker mode is headless — it runs neither approval gate.
- **Multi-person is now in scope** via triage (a prior "team CVs out of scope" note is retired). CV generation is still per-person from each person's real CV; the skill never edits `team.json` (the app owns it).