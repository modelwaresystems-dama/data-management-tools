# Phase 0 — Config register

Run this **every tender** before any tailoring. It exists so Howard is never surprised by scope, format, or depth halfway through a run. Present the nine questions below as a decision-register-style artifact (evidence/context first, then one card per question, recommended option pre-marked) or via `AskUserQuestion`, and get his answers before starting Phase 1.

The recommended defaults are tuned to the first validated run (Riyadh Re IT Strategy RFP). They are **recommendations, not locked behaviour** — Howard re-decides each tender.

| # | Question | Options | Recommended default |
|---|----------|---------|---------------------|
| 1 | **Whose CV?** | Howard only / team pack | **Howard only.** Team pack is out of scope until the skill supports per-person banks. |
| 2 | **Which output formats this run?** | PDF only / PDF + .docx / PDF + .pptx / all three | **PDF only.** Add the `.pptx` designed replica or the branded-editable `.docx` only if Howard asks for it this run. |
| 3 | **PDF visual fidelity?** | Lightly branded (clean, tailorable) / designed replica | **Lightly branded.** The PDF is the fast, tailored deliverable, not a pixel replica of the deck. (The designed replica lives in the `.pptx` when requested.) |
| 4 | **Tailoring depth?** | Full rewrite around the tender / light re-order only | **Full rewrite** — restructure and re-voice real experience into the tender's language and priorities. |
| 5 | **Gap handling?** | Closest-match drafts for approval / leave gaps blank / (never: silent fill) | **Closest-match drafts, each approved before it appears.** Never fabricate, never fill silently. |
| 6 | **Length target?** | Trim hard to scope-relevant only / keep fuller history | **Trim hard** — "credentials relevant to scope only" is the test. Cut off-scope history. Typically ~2 pages. |
| 7 | **Coverage map?** | Always produce / skip | **Always produce** the requirement → evidence → residual-gap map alongside the CV. |
| 8 | **Approval flow?** | Two stops (config + plan) / one stop / none | **Two stops** — this register, then the Phase 1 plan register. Generate only after the plan is approved. |
| 9 | **Bid-specific focus items to add to the bank this run?** | None beyond the standing bank / Howard names extras | **Confirm the standing bank as-is** unless Howard names bid-specific experience to foreground. Anything added must be real and confirmed by him. |

After Howard answers, carry Q2's format choice and Q6's length into Phase 2, and Q9's additions into the Phase 1 evidence map. If any answer conflicts with what a supplied CV or the tender demands, raise it as a question rather than resolving it silently.
