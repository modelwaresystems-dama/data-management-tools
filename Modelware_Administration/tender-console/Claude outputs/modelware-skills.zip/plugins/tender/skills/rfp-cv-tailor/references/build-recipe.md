# Phase 2 — Build recipe

Read this only at Phase 2, after Howard has approved the plan. It keeps the visual output consistent run-to-run so tailoring effort goes into content, not re-deriving the branding each time.

## Branding source — extract once per run from the deck

Howard's designed CV **.pptx** carries the branding. Extract from it before building any format:

- **Headshot:** the largest JPEG under `ppt/media/` in the unzipped deck.
  ```bash
  cd /tmp && rm -rf cvdeck && mkdir cvdeck && cd cvdeck
  unzip -o "<path-to-CV>.pptx" >/dev/null
  ls -lS ppt/media/*.jp*g | head -1     # largest JPEG = the headshot
  ```
- **Brand palette** (from the deck's `ppt/theme/theme1.xml`; these are the confirmed Modelware values — verify against the actual deck and prefer what the deck contains):
  - Navy `#0E2841`
  - Teal `#156082`
  - Accent blue `#0F9ED5`

If no `.pptx` is supplied, ask Howard for the deck rather than guessing branding.

## Format 1 — PDF (always; the default deliverable)

Lightly branded, clean single-flow **A4**, scope-trimmed. Not a replica of the deck — this is the fast, tailored artefact.

1. Author a **self-contained HTML** file: inline all CSS, embed the headshot as a `data:` URI, use **system fonts only** (no external font fetches). A4 page via `@page { size: A4; }`. Use the brand palette above for headings/rules; keep body high-contrast and print-safe.
2. Render to PDF with headless Chromium via Playwright. Chromium is pre-installed here — do **not** run `playwright install`.
   ```js
   const { chromium } = require('playwright');
   // Env sets PLAYWRIGHT_BROWSERS_PATH=/opt/pw-browsers.
   // Known binary: /opt/pw-browsers/chromium/chrome-linux/chrome
   // If that path is absent, find it: `find /opt/pw-browsers -name chrome -type f`
   const browser = await chromium.launch({ executablePath: '/opt/pw-browsers/chromium/chrome-linux/chrome' });
   const page = await browser.newPage();
   await page.setContent(html, { waitUntil: 'networkidle' });
   await page.pdf({ path: out, printBackground: true, preferCSSPageSize: true });
   await browser.close();
   ```
   `printBackground: true` keeps the brand fills; `preferCSSPageSize: true` honours the `@page` A4.
3. Verify the PDF opens and is the expected page count before delivering.

## Format 2 — .pptx (on request; the designed replica)

The full designed 3-page replica of Howard's CV deck, retailored to the tender. Because the deck *is* the design, reproduce it faithfully.

- Read the **pptx** output skill's SKILL.md first.
- Start from the supplied deck's structure/layout; replace the body content with the approved tailored text and re-ordered sections. Keep the headshot, palette, and layout.
- This is the one place "designed replica" applies — invest in fidelity here, not in the PDF or DOCX.

## Format 3 — .docx (on request; branded-editable)

A clean, Modelware-branded Word CV built to be **hand-edited** by Howard — not a replica of the deck. Favour editability over pixel-fidelity.

- Read the **docx** output skill's SKILL.md first.
- Use real Word styles (Heading 1/2, body), the brand palette for headings/rules, and place the headshot in the header or top block. Keep structure simple so Howard can edit freely in Word.
- Do not try to force the deck's designed layout into Word — that produces something fragile and hard to edit. If a designed look is what's wanted, that's the `.pptx`.

## Coverage map (always)

Produce alongside the CV as a short companion (PDF or the same format as the CV): a table of **requirement → evidence in the tailored CV → residual gap**, plus a one-line note of residual gaps for the wider proposal narrative. Never soften a real gap.

## Delivery

- Copy every produced file to `/mnt/user-data/outputs/` and deliver each with `SendUserFile`.
- Name files clearly, e.g. `Howard_Diesel_CV_<Tender>.pdf`, `Howard_Diesel_<Tender>_CoverageMap.pdf`, and `.pptx` / `.docx` variants when produced.
- In the message, note any residual gaps (e.g. reinsurance specificity, Arabic) so Howard can address them in the proposal rather than the CV.
