# modelware-skills

The single source of truth for Modelware's Claude skills. One marketplace repo
that **both** your Claude app and the Tender Console GitHub Actions worker read
from — so there is never a second copy to drift.

## What's here

- **`tender`** plugin → skill **`/tender:rfp-cv-tailor`** (v1.6.0): tailor a CV
  to an RFP, draft the Expert Services Agreement, and run the bid / partner /
  leave triage. The same skill runs interactively in your Claude and headlessly
  as the Tender Console assessment worker.

## Use it in your Claude (interactive)

```
/plugin marketplace add modelwaresystems-dama/modelware-skills
/plugin install tender@modelware-skills
```

Then the skill is `/tender:rfp-cv-tailor`. **Retire the old synced
`rfp-cv-tailor` account skill** once this is installed, so the plugin is the
only copy.

## Use it in the worker (GitHub Actions)

The data repo's `.github/workflows/assessment-worker.yml` installs this
marketplace and plugin and invokes `/tender:rfp-cv-tailor` — see that repo's
`WORKER-SETUP.md`.

## Editing the skill

Edit `plugins/tender/skills/rfp-cv-tailor/SKILL.md` **here**, commit, push.
Both your Claude (after `/plugin update`) and the next worker run pick up the
change. One edit, one source.
