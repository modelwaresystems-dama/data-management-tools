# Howard's experience bank (confirmed focus items)

Experience Howard wants foregrounded that his base CV under-plays or omits. Every item here is confirmed by Howard. Confirm and extend it per bid at Phase 1 — do not invent details or add specifics he hasn't given.

**Source of truth:** Howard's memory file `cv-experience-bank` (project CRM). This file is a mirror for offline use. If the two disagree, trust memory and confirm with Howard before relying on the difference.

## KSA / GCC delivery

- Working in **Saudi Arabia (Riyadh) since 2021**; strong working understanding of KSA business culture. **Arabic not spoken.**
- **GOSI** (General Organisation for Social Insurance, KSA) — Data Strategy, Data Governance and Data Quality. This is KSA *insurance-sector* work.
- **NDMO** (National Data Management Office, KSA) — built **Version 2** of the NDMO in partnership with **PwC**; did the NDMO V2 Domain Specification Review, all domains.
- **SDAIA** — CDMP training, **1,000+ professionals (2021–2023)**.
- **MODON** — MODON NDMO P1 compliance delivery (6 months).

## Insurance / Lloyd's

- **Talsen** — Lloyd's-compliant insurer based in London. Engagement **26 Feb 2021 – 12 Oct 2023**. Delivered the full set of **Lloyd's of London Bordereaux compliance documents** plus an **MI capability** for business users to validate submissions (delivered via Modelware). Fills the insurance + international-experience gap that bids like Riyadh Re prize.
- **MetLife (India)** — provided AI Governance training.
- **No reinsurance-specific engagement** — a genuine residual gap for reinsurance RFPs. Surface it honestly; never imply reinsurance delivery.

## Training developed & delivered

- **SITA** — "Unified Governance for Data, Records and AI" AND "Integrated Architecture for Business, Data, Application and Technology" — each 60 delegates, 3-week delivery, 3 months preparation.
- **AGGPSA** — AI Capability training; Responsible AI & Ethical Maturity Assessment work and training.
- Generally worth foregrounding: **Data Governance & Operating Model** experience; the fact that Howard **builds customer training that directly addresses tender subject areas** (data / AI / architecture strategy) — evidence of applied, current expertise.

## Also reliably relevant

When a tender is KSA/GCC or insurance-flavoured, these support the pitch: SDAIA (1,000+ trained), NDMO V2, MODON (Saudi credentials); MetLife, MMI, Innovation Group, Halcyon (insurance); data-maturity assessments + roadmaps (MTN, UJ, CCBSA, SARB EIM).

## Standing gaps to expect (surface, never mask)

- Arabic language.
- Reinsurance-specific delivery.
- Where a tender wants deep IT-infrastructure / cloud / cyber, or investment/licensing costing, check the CV honestly — these have shown up as partials/gaps before.
